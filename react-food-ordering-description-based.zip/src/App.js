import React from 'react';

function App() {
  return (
    <div className="container">
      <h1>Description</h1>
      <p>
        Built with ReactJS, provides a clean and intuitive interface for users to browse, customize,
        and order a wide variety of food items with ease. Designed for all types of cuisine—from street
        food to fine dining—the platform ensures a smooth and engaging user experience from menu selection
        to final checkout.
      </p>
      <p>
        With real-time cart updates, responsive design, and clear navigation, the interface prioritizes
        usability across devices, making online food ordering quick, convenient, and enjoyable.
      </p>
    </div>
  );
}

export default App;
